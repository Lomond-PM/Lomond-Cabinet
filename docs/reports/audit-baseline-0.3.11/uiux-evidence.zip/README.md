# UI/UX Audit Evidence

Read `UIUX_AUDIT.md`, then `COVERAGE.md`.

The two JavaScript files in `sources/` were reconstructed from the GitHub connector's content and verified against their exact Git blob SHA-1 values. The probe asserts these hashes before testing.

Run `python probes/run-browser-probes.py` with Playwright and `/usr/bin/chromium` installed. Adjust the executable path for another local environment. No AE/CEP access is used. No production files or storage are modified.

`browser-results.json` contains the actually executed results. CSS selector and Escape handler excerpts are explicitly separated from complete, hash-verified module sources. Remaining dependencies are test fixtures.

The audit proposes implementation and product work; it does not approve roadmap changes or assign a release number.
