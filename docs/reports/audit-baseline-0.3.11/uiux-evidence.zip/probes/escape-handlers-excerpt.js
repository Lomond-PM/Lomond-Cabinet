/* Hand-copied handlers from coreUi.js and main.js. All downstream dependencies
   in this fixture are explicit spies. This is not the full Settings controller. */
window.escapeProbe = { menuCloses: 0, settingsCloses: 0, pickerCloses: 0, defaultPreventedAtDocument: false };
var viewport = { querySelectorAll: function () { return []; }, querySelector: function () { return null; } };
var control = { classList: { contains: function () { return true; } } };
function close() { escapeProbe.menuCloses++; }
function open() {}
function setValue() {}
function triggerKeydown(event) {
    var buttons = viewport.querySelectorAll(".select-option:not(:disabled)");
    var selected = viewport.querySelector(".select-option.is-selected");
    var selectedIndex = 0;
    var nextIndex;
    var i;
    for (i = 0; i < buttons.length; i++) if (buttons[i] === selected) selectedIndex = i;
    if (event.keyCode === 13 || event.keyCode === 32) {
        event.preventDefault();
        if (control.classList.contains("is-open")) close();
        else open();
    } else if (event.keyCode === 27) {
        event.preventDefault();
        close(true);
    } else if (event.keyCode === 38 || event.keyCode === 40) {
        event.preventDefault();
        if (!buttons.length) return;
        nextIndex = selectedIndex + (event.keyCode === 40 ? 1 : -1);
        if (nextIndex < 0) nextIndex = buttons.length - 1;
        if (nextIndex >= buttons.length) nextIndex = 0;
        setValue(buttons[nextIndex].getAttribute("data-value"), true);
    }
}
function closeRegistryColorPicker() { escapeProbe.pickerCloses++; }
function closeVelaSettingsSurface() { return false; }
function requestCloseSettings() { escapeProbe.settingsCloses++; }
document.querySelector('#select-trigger').addEventListener('keydown', triggerKeydown);
document.addEventListener('keydown', function (event) { escapeProbe.defaultPreventedAtDocument = event.defaultPrevented; });
document.addEventListener("keydown", function (event) {
    if (event.keyCode === 27) {
        closeRegistryColorPicker();
        if (closeVelaSettingsSurface()) return;
        requestCloseSettings();
    }
});
