"""UI component/selector probes. Not a complete application or CEP harness.
Run: python probes/run-browser-probes.py
Uses two Git-blob-verified production modules with synthetic DOM/dependencies.
"""
from pathlib import Path
import hashlib
import json
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
expected = {
    'velaComposerView.js': 'df647030827e83fbcc2fa52226a251282bee023d',
    'velaConfirmationView.js': '81214c055ac9f3bab906c820bd5df6c206fc1425',
}
hashes = {}
for name, want in expected.items():
    content = (ROOT / 'sources' / name).read_bytes()
    got = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    assert got == want, (name, got, want)
    hashes[name] = {'expectedGitBlob': want, 'actualGitBlob': got, 'bytes': len(content)}

results = []
with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 800, 'height': 600})
    page.set_content('''<!doctype html><html><head><meta charset="UTF-8"><style>
      :root { --ui-scale:.92; --type-supporting-size:9.66px; --vela-inline-gap:7.36px;
        --vela-controls-min-height:20.24px; --vela-surface-inset:11.04px;
        --radius-sm:9.2px; --text-secondary:#333; --text-muted:#555; }
      body { font:12px Arial,sans-serif; } #actions {display:flex;width:240px;gap:7.36px;}
      button {flex:0 0 auto;} textarea {display:block;}
    </style></head><body>
      <section id="surface" class="vela-surface" data-layout="narrow">
        <div class="vela-status-slot" id="status" data-detail-empty="false">
          <span class="vela-status-text" id="primary">Context stale. Request blocked.</span>
          <span class="vela-experimental-status" id="experimental">Experimental / not qualified</span>
        </div>
        <textarea id="composer"></textarea><div id="actions"></div>
      </section><button id="after">After component</button></body></html>''')
    page.add_style_tag(path=str(ROOT / 'probes' / 'vela-layout-excerpt.css'))
    for name in expected:
        page.add_script_tag(path=str(ROOT / 'sources' / name))
    page.evaluate('''() => {
      window.dictionary = {
        'vela.surfaceReview':'Review', 'vela.surfaceApprove':'Approve', 'vela.surfaceReject':'Reject',
        'vela.surfaceSend':'Send', 'vela.surfaceCancel':'Cancel',
        'vela.surfaceConfirmationValue':'Opacity {before}% → {proposed}%',
        'vela.surfaceConfirmationLayerName':'Layer name: {before} → {proposed}'
      };
      window.t = (key,args) => { let s = dictionary[key] || key;
        for (const k of Object.keys(args||{})) s=s.replace('{'+k+'}',String(args[k])); return s; };
      window.sent=[];
      window.cv=VelaComposerView.create({composer:document.querySelector('#composer'),
        actionSlot:document.querySelector('#actions'),t,onSend:m=>sent.push(m)});
      window.confirmView=VelaConfirmationView.create({actionSlot:document.querySelector('#actions'),t});
    }''')
    def evaluate_case(case_id, js):
        result=page.evaluate(js)
        results.append({'id':case_id, **result})
        return result

    r=evaluate_case('UXP01-narrow-status', '''() => {
      const el=document.querySelector('#primary'),cs=getComputedStyle(el);
      return {primaryText:el.textContent,position:cs.position,clip:cs.clip,width:el.getBoundingClientRect().width,
        experimentalVisible:getComputedStyle(document.querySelector('#experimental')).display!=='none'};
    }''')
    assert r['position']=='absolute' and r['width']==1
    r=evaluate_case('UXP02-empty-detail-control', '''() => {
      document.querySelector('#status').dataset.detailEmpty='true';
      const cs=getComputedStyle(document.querySelector('#primary'));
      return {position:cs.position,clip:cs.clip,experimentalDisplay:getComputedStyle(document.querySelector('#experimental')).display};
    }''')
    assert r['position']=='static' and r['experimentalDisplay']=='none'

    r=evaluate_case('UXP03-confirmation-target-display', '''() => {
      cv.render('confirm',true,false);
      confirmView.render('confirm',{valueKind:'number',beforeValue:100,proposedValue:63,
        compositionName:'Comp A',targetDisplayName:'Layer A'});
      const el=confirmView.getElementsForTest().summary;
      return {summary:el.textContent,containsTarget:el.textContent.includes('Layer A'),title:el.getAttribute('title'),
        ariaLabel:el.getAttribute('aria-label'),tabindex:el.getAttribute('tabindex')};
    }''')
    assert not r['containsTarget'] and r['summary']=='Opacity 100% → 63%'
    r=evaluate_case('UXP04-long-name-ellipsis', '''() => {
      confirmView.render('confirm',{valueKind:'string',beforeValue:'Layer with an existing long name',
        proposedValue:'Render_Final_Long_Layer_Name_'+ 'X'.repeat(100)});
      const el=confirmView.getElementsForTest().summary,cs=getComputedStyle(el);
      return {clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,textOverflow:cs.textOverflow,
        title:el.title,focusable:el.tabIndex>=0};
    }''')
    assert r['scrollWidth']>r['clientWidth'] and r['textOverflow']=='ellipsis' and not r['title']

    page.evaluate("() => {confirmView.render('send'); document.querySelector('#composer').value='Draft'; cv.render('send',true,false);}")
    page.focus('#composer')
    page.keyboard.press('Control+Enter')
    r=evaluate_case('UXP05-no-send-shortcut', '() => ({sendCalls:sent.length})')
    assert r['sendCalls']==0
    page.evaluate("() => cv.getElementsForTest().send.focus()")
    page.keyboard.press('Enter')
    r=evaluate_case('UXP06-send-button-keyboard-control', '() => ({sendCalls:sent.length})')
    assert r['sendCalls']==1

    r=evaluate_case('UXP07-offline-draft-disabled', '''() => {cv.render('send',false,false);const c=document.querySelector('#composer');return {disabled:c.disabled,readOnly:c.readOnly};}''')
    assert r['disabled'] and r['readOnly']
    r=evaluate_case('UXP08-other-active-draft-control', '''() => {cv.render('send',true,true);const c=document.querySelector('#composer');return {disabled:c.disabled,readOnly:c.readOnly,sendDisabled:cv.getElementsForTest().send.disabled};}''')
    assert not r['disabled'] and not r['readOnly'] and r['sendDisabled']
    page.evaluate("() => {cv.render('send',true,false);cv.getElementsForTest().send.focus();cv.render('cancel',true,true);}")
    page.wait_for_timeout(50)
    results.append({'id':'UXP09-focused-control-transition','observation':page.evaluate('''() => ({
      activeTag:document.activeElement.tagName, activeText:document.activeElement.textContent.slice(0,80),
      isCancelFocused:document.activeElement===cv.getElementsForTest().cancel,
      isComposerFocused:document.activeElement===document.querySelector('#composer')})''')})
    escape_page = browser.new_page()
    escape_page.set_content('<!doctype html><button id="select-trigger">Select</button>')
    escape_page.add_script_tag(path=str(ROOT / 'probes' / 'escape-handlers-excerpt.js'))
    escape_page.focus('#select-trigger')
    escape_page.keyboard.press('Escape')
    escaped = escape_page.evaluate('() => escapeProbe')
    assert escaped['menuCloses'] == 1 and escaped['settingsCloses'] == 1
    assert escaped['defaultPreventedAtDocument'] is True
    results.append({'id':'UXP10-escape-bubbles-to-parent','scope':'exact handler excerpts, downstream spies',**escaped})
    escape_page.close()
    browser_version=browser.version
    browser.close()

report={'commit':'b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a',
 'environment':{'browser':'Chromium','version':browser_version,'host':'Linux, synthetic DOM, not CEP/AE'},
 'sourceVerification':hashes,'cases':results,
 'scope':'Component and CSS-selector behavior only; no complete style.css, main.js or real Runtime wiring.'}
(ROOT/'browser-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
