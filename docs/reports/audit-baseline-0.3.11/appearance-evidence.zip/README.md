# 外观专项审计证据包

这是只读审计产物，不是修复补丁，不会连接或修改 AE、GitHub 或你的项目。

基线：Lomond-PM/Lomond-Cabinet@b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a。

先读 APPEARANCE_AUDIT.md；范围见 COVERAGE.md。JSON 保存本轮实际执行结果。

## 重跑

在解压目录中运行（Node.js；本次环境 v22.16.0）：

```powershell
node ./probes/run-state-probes.js > ./state-results.json
node ./probes/run-ui-probes.js
node ./probes/run-pixel-probes.js
```

CSS 探针需要 Python、已安装的 Playwright 和 Chromium/Chrome。使用已有环境，不会自动安装依赖：

```powershell
python ./probes/run-css-probe.py
```

如浏览器不在 PATH，可设置 CHROMIUM_PATH 指向浏览器可执行文件。CSS 探针在隔离 headless Chromium 中运行，不是 AE/CEP。

## 证据性质

- 生产函数经手工转录并压缩格式，使用有声明的依赖夹具，不是完整仓库原文件。
- 数值内核是固定 Palette 分支，recipe 是测试夹具，不包含 PRNG/Canvas/cache/ThemeMap。
- CSS 仅组合所审规则片段，不包含整个 style.css 级联。
- 断言成功表示复现了缺陷或正常对照；不是修复成功，也不是仓库回归 PASS。
- X01 是经双语文案核对而排除的疑点；不要据此改摘要统计。
- 未观察到的原生 AE/CEP 行为不作保证。
