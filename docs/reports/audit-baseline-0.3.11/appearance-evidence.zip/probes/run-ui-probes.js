'use strict';
// Production function excerpts transcribed from pinned sources. The DOM/event system
// below is a controlled fixture; this is not a native browser or CEP acceptance run.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const cases=[];
function test(name,fn){ cases.push({name,status:'behavior-reproduced',evidence:fn()}); }
class Target {
  constructor(){this.handlers=new Map();}
  addEventListener(k,f){if(!this.handlers.has(k))this.handlers.set(k,new Set());this.handlers.get(k).add(f);}
  removeEventListener(k,f){this.handlers.get(k)?.delete(f);}
  fire(k,e={}){for(const f of [...(this.handlers.get(k)||[])])f.call(this,e);}
  count(){return [...this.handlers.values()].reduce((a,s)=>a+s.size,0);}
}
function classes(){const s=new Set();return {add:k=>s.add(k),remove:k=>s.delete(k),contains:k=>s.has(k)};}
// coreUi.js::bindResizeGrip; only indentation and whitespace condensed.
function bindResizeGrip(options) {
  var grip=options.grip,frame=options.frame,direction=options.direction,doc=grip.ownerDocument,win=doc.defaultView,activePointer=null;
  function clamp(value,min,max){if(typeof min==='number')value=Math.max(min,value);if(typeof max==='number')value=Math.min(max,value);return value;}
  function down(event){
    var startX,startY,startWidth,startHeight,parent;
    if(!event||event.button!==0)return;
    startX=event.clientX;startY=event.clientY;startWidth=frame.offsetWidth;startHeight=frame.offsetHeight;parent=frame.parentNode;
    activePointer=event.pointerId;if(grip.setPointerCapture&&activePointer!==undefined)grip.setPointerCapture(activePointer);
    doc.body.classList.add('is-resizing-ui-surface');event.preventDefault();event.stopPropagation();
    function move(moveEvent){
      var maxWidth=typeof options.maxWidth==='number'?options.maxWidth:(parent&&parent.clientWidth?parent.clientWidth:null);
      var maxHeight=typeof options.maxHeight==='number'?options.maxHeight:null;
      if(direction==='horizontal'||direction==='both')frame.style.width=clamp(startWidth+moveEvent.clientX-startX,options.minWidth||0,maxWidth)+'px';
      if(direction==='vertical'||direction==='both')frame.style.height=clamp(startHeight+moveEvent.clientY-startY,options.minHeight||0,maxHeight)+'px';
      moveEvent.preventDefault();
    }
    function end(endEvent){
      doc.removeEventListener('pointermove',move);doc.removeEventListener('pointerup',end);doc.removeEventListener('pointercancel',end);win.removeEventListener('blur',end);
      if(grip.releasePointerCapture&&activePointer!==null&&grip.hasPointerCapture&&grip.hasPointerCapture(activePointer))grip.releasePointerCapture(activePointer);
      activePointer=null;doc.body.classList.remove('is-resizing-ui-surface');if(endEvent&&endEvent.preventDefault)endEvent.preventDefault();
    }
    doc.addEventListener('pointermove',move);doc.addEventListener('pointerup',end);doc.addEventListener('pointercancel',end);win.addEventListener('blur',end);
  }
  grip.addEventListener('pointerdown',down);
  return function(){grip.removeEventListener('pointerdown',down);doc.body.classList.remove('is-resizing-ui-surface');};
}
function resizeFixture(){const doc=new Target(),win=new Target(),grip=new Target();doc.defaultView=win;doc.body={classList:classes()};grip.ownerDocument=doc;const frame={offsetWidth:100,offsetHeight:80,style:{},parentNode:{clientWidth:500}};return {doc,win,grip,frame};}
const event=(x,y)=>({button:0,clientX:x,clientY:y,pointerId:1,preventDefault(){},stopPropagation(){}});
test('AP-06 disposing active ResizeGrip leaves gesture listeners and permits a later write',()=>{
  const f=resizeFixture(),dispose=bindResizeGrip({...f,direction:'both'});f.grip.fire('pointerdown',event(0,0));
  const activeListeners=f.doc.count()+f.win.count();dispose();f.frame.parentNode=null;f.doc.fire('pointermove',event(30,20));
  const result={activeListeners,listenersAfterDispose:f.doc.count()+f.win.count(),detachedFrameStyle:{...f.frame.style},newDownListeners:f.grip.count()};
  assert.equal(result.listenersAfterDispose,4);assert.equal(result.detachedFrameStyle.height,'100px');assert.equal(result.newDownListeners,0);
  f.doc.fire('pointerup',event(30,20));assert.equal(f.doc.count()+f.win.count(),0);return result;
});
test('AP-06 control normal pointerup clears active gesture before disposal',()=>{
  const f=resizeFixture(),dispose=bindResizeGrip({...f,direction:'both'});f.grip.fire('pointerdown',event(0,0));f.doc.fire('pointerup',event(5,5));dispose();
  assert.equal(f.doc.count()+f.win.count()+f.grip.count(),0);return {remainingListeners:0};
});
// main.js::linkRange / linkPersistedRange. Clamp/byId are fixture seams.
let controls={};
function byId(id){return controls[id];}
function clampNumber(v,f,min,max){let n=parseFloat(v);if(isNaN(n))n=f;if(typeof min==='number')n=Math.max(min,n);if(typeof max==='number')n=Math.min(max,n);return n;}
function linkRange(rangeId,numberId,min,max){var range=byId(rangeId),number=byId(numberId);function syncFromRange(){number.value=range.value;}function syncFromNumber(){var n=clampNumber(number.value,parseFloat(range.value),min,max);number.value=n;range.value=n;}range.addEventListener('input',syncFromRange);number.addEventListener('change',syncFromNumber);syncFromRange();}
function linkPersistedRange(rangeId,numberId,min,max,onChange){var range=byId(rangeId),number=byId(numberId);if(!range||!number)return;function notify(){if(onChange)onChange();}linkRange(rangeId,numberId,min,max);range.addEventListener('input',notify);number.addEventListener('change',notify);}
test('AP-05 legacy range persists on every input, before gesture completion',()=>{
  const range=new Target(),number=new Target();range.value='.92';controls={range,number};let writes=0;
  linkPersistedRange('range','number',.62,1.18,()=>{writes++;});
  for(const v of ['.95','1.00','1.05']){range.value=v;range.fire('input');}
  assert.equal(writes,3);return {inputEvents:3,changeEvents:0,writesBeforeChangeOrPointerUp:writes,numberValue:number.value};
});
// Actual projection and tail assignments, with unrelated rendering dependencies omitted.
function toneForState(state){return ({completed:'success',busy:'processing',pending:'processing',error:'error'})[state]||'idle';}
function completedProjection(){return Object.freeze({state:'completed',tone:toneForState('completed')});}
function projectOtherRunning(projection,availability){
 const out={text:projection.state};
 if(availability.other)out.text='vela.conversationOtherRunning';
 out.other=availability.other?'true':'false';
 out.surfaceState=projection.state;
 out.tone=projection.tone;
 return out;
}
test('AP-07 other-conversation label retains selected completed projection tone',()=>{
 const output=projectOtherRunning(completedProjection(),{other:true,busy:true});
 assert.equal(output.text,'vela.conversationOtherRunning');assert.equal(output.tone,'success');
 return {output,contractToneForBusy:toneForState('busy'),limitation:'tail-assignment fixture, not full SurfaceController or native UI'};
});
test('AP-07 control without other activity is coherent completed/success',()=>{
 const output=projectOtherRunning(completedProjection(),{other:false,busy:false});
 assert.equal(output.text,'completed');assert.equal(output.tone,'success');return {output};
});

const result={baseline:'b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a',type:'production-function-excerpts-with-event-fixtures',cases};
fs.writeFileSync(path.join(__dirname,'..','ui-results.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
