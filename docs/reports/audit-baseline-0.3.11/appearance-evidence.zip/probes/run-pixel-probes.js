'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {createFixedPalette,renderFieldPixels}=require('./fixed-palette-kernel');
const params={warp:1,warpIrregularity:1,flowComplexity:1,flowContinuity:1,ribbonWidth:.14,gradientBias:.7,highlightConcentration:.52,highlightArea:.06,secondaryHueInfluence:.58,accentPresence:.46,highlightTintShift:.62,contrast:.92,depth:.8,hueShift:0,saturation:.84,brightness:.88,grain:.05,paletteStrategy:'curatedLuminous'};
const palette=createFixedPalette({id:'fixturePalette',signature:'fixture-v1',palette:{family:'fixture',colors:{shadow:'#102030',base:'#357090',secondary:'#80aaff',highlight:'#eef8ff'},stops:[0,.34,.74,1],weights:{shadow:.26,base:.5,secondary:.16,highlight:.08}}});
const fixed={target:'icon',seedHash:1234567,palette,direction:.8,phaseA:.4,phaseB:2.1,phaseC:1.3,accentRibbonIndex:0,highlight:{x:.6,y:.3,angle:1,stretch:1.1},vortices:[{x:.3,y:.2,radius:.4,strength:.5},{x:.7,y:.8,radius:.3,strength:-.4}],ribbons:[{offset:-.1,widthScale:1,frequencyA:1.6,frequencyB:3.2,amplitudeA:.15,amplitudeB:.05,phaseA:.8,phaseB:2.4,polarity:1},{offset:.2,widthScale:.85,frequencyA:2,frequencyB:3,amplitudeA:.14,amplitudeB:.04,phaseA:2,phaseB:.1,polarity:-1}]};
const render=(patch)=>renderFieldPixels(48,48,{...fixed,params:{...params,...patch}});
const hash=a=>crypto.createHash('sha256').update(a).digest('hex');
const cases=[];
for(const [parameter,lo,hi,expected] of [['saturation',0,1.4,false],['brightness',.2,1.4,false],['hueShift',-30,30,false],['contrast',0,1,true]]){
 const a=render({[parameter]:lo}),b=render({[parameter]:hi});let differingBytes=0;for(let i=0;i<a.length;i++)if(a[i]!==b[i])differingBytes++;
 assert.equal(differingBytes>0,expected);cases.push({name:'AP-04 fixed Palette '+parameter,status:expected?'sensitivity-control-passed':'no-pixel-effect-reproduced',evidence:{parameter,values:[lo,hi],dimensions:[48,48],differingBytes,hashes:[hash(a),hash(b)]}});
}
const result={baseline:'b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a',type:'fixed-palette-numerical-kernel-transcription-with-fixture-recipe',limitations:['Not complete engine execution','No native Canvas, cache, ThemeMap, CEP or AE','hueShift is a source parameter, not asserted to be a currently exposed Home slider'],cases};
fs.writeFileSync(path.join(__dirname,'..','pixel-results.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
