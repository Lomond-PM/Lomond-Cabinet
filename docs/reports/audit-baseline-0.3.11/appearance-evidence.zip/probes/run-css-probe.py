"""Isolated CSS excerpt integration. Chromium is NOT CEP and the full style.css
cascade is not loaded. Values below verify the authored Vela rules under a
controlled parent, not a screenshot/acceptance of the installed product.
"""
import json
import os
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright
css = """
:root { --ui-scale: 0.92; --appearance-type-body-scale: 1; --appearance-type-supporting-scale: 1;
--type-body-size: calc(12px * var(--appearance-type-body-scale) * var(--ui-scale));
--type-supporting-size: calc(10.5px * var(--appearance-type-supporting-scale) * var(--ui-scale)); }
body { font-size: var(--type-body-size); }
.vela-transcript-scroll { color: #aaa; }
.vela-transcript-message {font-size: var(--type-supporting-size); line-height: 1.5; white-space: pre-wrap;}
.vela-transcript-transient-segment {padding:7px 10px; border-left:2px solid #555; color:#aaa;}
.vela-transcript-transient-text {margin-top:6px; color:#eee; white-space:pre-wrap;}
"""
html = '<style>'+css+'</style><div class="vela-transcript-scroll"><section class="vela-transcript-transient-segment"><div class="vela-transcript-transient-text" id="stream">same text</div></section><p class="vela-transcript-message" id="terminal">same text</p></div>'
with sync_playwright() as p:
    executable = os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
    if not executable:
        raise RuntimeError('Set CHROMIUM_PATH to an installed Chromium/Chrome executable. This probe does not install a browser.')
    browser=p.chromium.launch(executable_path=executable,headless=True,args=['--no-sandbox'])
    page=browser.new_page()
    page.set_content(html)
    cases=[]
    for scale in [0.62,0.92,1.18]:
        page.evaluate('(v)=>document.documentElement.style.setProperty("--ui-scale",String(v))',scale)
        value=page.evaluate('''() => {const s=getComputedStyle(document.getElementById('stream')),t=getComputedStyle(document.getElementById('terminal')),segment=getComputedStyle(document.querySelector('section'));return {streamFont:s.fontSize,terminalFont:t.fontSize,segmentPadding:segment.padding,streamTopMargin:s.marginTop};}''')
        assert value['streamFont']!=value['terminalFont']
        assert value['segmentPadding']=='7px 10px'
        cases.append({'name':'AP-08 isolated Vela CSS at UI Scale '+str(scale),'status':'excerpt-behavior-confirmed','evidence':value})
    browser.close()
result={'baseline':'b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a','type':'isolated-css-excerpts-headless-chromium','limitations':['Not full CSS cascade','Not CEP/AE','Not full transcript lifecycle or screenshot acceptance'], 'cases':cases}
Path(__file__).resolve().parent.parent.joinpath('css-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
