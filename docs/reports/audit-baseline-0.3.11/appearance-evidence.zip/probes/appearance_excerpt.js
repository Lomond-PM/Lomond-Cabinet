/* Production function excerpts from Lomond-PM/Lomond-Cabinet @ b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a.
 * Source: client/js/appearance/appearanceStateStore.js and appearanceResolver.js.
 * UMD wrappers and unrelated exports are omitted; injected registry/style/storage are fixtures.
 * This is NOT the complete repository or an AE/CEP integration test. */
'use strict';
var STORAGE_KEY = "AEToolbox.appearance.v1";
function copyOverrides(source) {
    var result = {};
    var key;
    source = source && typeof source === "object" ? source : {};
    for (key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) { result[key] = source[key]; }
    }
    return result;
}
function createStore(options) {
    options = options || {};
    var storage = options.storage;
    var registry = options.registry;
    var overrides = {};
    function normalize(candidate) {
        var result = {};
        var source = candidate && candidate.version === 1 && candidate.overrides && typeof candidate.overrides === "object" ? candidate.overrides : {};
        var key;
        var checked;
        for (key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key) && registry && registry.isAppearanceOverride(key)) {
                checked = registry.validate(key, source[key]);
                if (checked.valid) { result[key] = checked.value; }
            }
        }
        return { version: 1, overrides: result };
    }
    function load() {
        var parsed = null;
        var raw;
        try {
            raw = storage && typeof storage.getItem === "function" ? storage.getItem(STORAGE_KEY) : null;
            parsed = raw ? JSON.parse(raw) : null;
        } catch (error) { parsed = null; }
        overrides = normalize(parsed).overrides;
        return copyOverrides(overrides);
    }
    function save() {
        try {
            if (storage && typeof storage.setItem === "function") {
                storage.setItem(STORAGE_KEY, JSON.stringify({ version: 1, overrides: overrides }));
            }
        } catch (error) {
            return { version: 1, overrides: copyOverrides(overrides), persisted: false };
        }
        return { version: 1, overrides: copyOverrides(overrides), persisted: true };
    }
    function setOverride(id, value) {
        var checked;
        if (!registry || !registry.isAppearanceOverride(id)) { return false; }
        checked = registry.validate(id, value);
        if (!checked.valid) { return false; }
        overrides[id] = checked.value;
        return true;
    }
    function removeOverride(id) {
        if (!Object.prototype.hasOwnProperty.call(overrides, id)) { return false; }
        delete overrides[id];
        return true;
    }
    return Object.freeze({
        storageKey: STORAGE_KEY, load: load, normalize: normalize, save: save,
        getOverrides: function () { return copyOverrides(overrides); },
        getOverride: function (id) { return Object.prototype.hasOwnProperty.call(overrides, id) ? overrides[id] : null; },
        setOverride: setOverride, removeOverride: removeOverride,
        resetCategory: function (category) {
            var key; var parameter; var changed = false;
            for (key in overrides) {
                if (Object.prototype.hasOwnProperty.call(overrides, key)) {
                    parameter = registry.get(key);
                    if (parameter && parameter.category === category) { delete overrides[key]; changed = true; }
                }
            }
            return changed;
        },
        resetAll: function () { overrides = {}; },
        snapshot: function () { return { version: 1, overrides: copyOverrides(overrides) }; }
    });
}
var DESIGN_DEFAULTS = Object.freeze({
    "base.accent": "#d6b25e", "base.canvas": "#050403", "layout.scale": 0.92,
    "motion.speed": 1, "surface.panel": "#0b0a08", "text.primary": "#f6f0df",
    "text.secondary": { color: "#f6f0df", alpha: 0.66 },
    "text.tertiary": { color: "#f6f0df", alpha: 0.42 },
    "select.trigger.surface": "#0b0a08", "select.menu.surface": "#0b0a08",
    "typography.title.size": 1, "typography.sectionTitle.size": 1,
    "typography.fieldLabel.size": 1, "typography.body.size": 1,
    "typography.supporting.size": 1, "typography.code.size": 1,
    "action.primary.foreground": "#130f08"
});
var CSS_TARGETS = Object.freeze({
    "surface.panel": "--surface-panel", "text.primary": "--text-primary",
    "text.secondary": "--text-secondary", "text.tertiary": "--text-tertiary",
    "select.trigger.surface": "--select-trigger-surface", "select.menu.surface": "--select-menu-surface",
    "typography.title.sizeMultiplier": "--appearance-type-title-scale",
    "typography.sectionTitle.sizeMultiplier": "--appearance-type-section-title-scale",
    "typography.fieldLabel.sizeMultiplier": "--appearance-type-field-label-scale",
    "typography.body.sizeMultiplier": "--appearance-type-body-scale",
    "typography.supporting.sizeMultiplier": "--appearance-type-supporting-scale",
    "typography.code.sizeMultiplier": "--appearance-type-code-scale",
    "interaction.focus.ring": "--interaction-focus-ring", "interaction.focus.border": "--interaction-focus-border",
    "interaction.hover.border": "--interaction-hover-border", "interaction.hover.surface": "--interaction-hover-surface",
    "interaction.selected.surface": "--interaction-selected-surface", "interaction.selected.foreground": "--interaction-selected-foreground",
    "interaction.checked.surface": "--interaction-checked-surface", "action.primary.surface": "--action-primary-surface",
    "action.primary.hoverSurface": "--action-primary-hover-surface", "action.primary.foreground": "--action-primary-foreground",
    "selection.indicator.surface": "--selection-indicator-surface"
});
function normalizeHex(value, fallback) { return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value) ? value.toLowerCase() : fallback; }
function hexToRgb(hex) { return { r: parseInt(hex.slice(1,3),16), g:parseInt(hex.slice(3,5),16), b:parseInt(hex.slice(5,7),16) }; }
function channel(value) { var text=Math.max(0,Math.min(255,Math.round(value))).toString(16); return text.length<2?"0"+text:text; }
function mixHex(a,b,amount) { var left=hexToRgb(a),right=hexToRgb(b); return "#"+channel(left.r+(right.r-left.r)*amount)+channel(left.g+(right.g-left.g)*amount)+channel(left.b+(right.b-left.b)*amount); }
function rgba(hex,alpha) { var color=hexToRgb(hex);return "rgba("+color.r+", "+color.g+", "+color.b+", "+alpha+")"; }
function isValidColorAlphaValue(value) { return !!value && typeof value.color === "string" && /^#[0-9a-fA-F]{6}$/.test(value.color) && typeof value.alpha === "number" && isFinite(value.alpha) && value.alpha >= 0 && value.alpha <= 1; }
function normalizeColorAlphaValue(value,fallback) { var candidate=isValidColorAlphaValue(value)?value:fallback;return isValidColorAlphaValue(candidate)?{color:candidate.color.toLowerCase(),alpha:Number(candidate.alpha)}:null; }
function serializeColorAlphaValue(value) { var normalized=normalizeColorAlphaValue(value,null); if(!normalized)return "";return rgba(normalized.color,normalized.alpha); }
function copy(source) { var result={};var key;for(key in source){if(Object.prototype.hasOwnProperty.call(source,key)){result[key]=source[key];}}return result; }
function createResolver(options) {
    options=options||{};
    var registry=options.registry,store=options.store,rootStyle=options.rootStyle,runtime=options.runtime||{};
    var baseInputs=copy(DESIGN_DEFAULTS),previewOverrides={},resolved={};
    function themeDefaults() {
        var accent=normalizeHex(baseInputs["base.accent"],DESIGN_DEFAULTS["base.accent"]);
        var hot=mixHex(accent,"#ffffff",0.24);
        return {accent:accent,hot:hot,dark:mixHex(accent,"#000000",0.58),soft:rgba(accent,0.72),track:rgba(accent,0.24),focus:rgba(hot,0.62),button:rgba(accent,0.86),separator:rgba(accent,0.16),panelBorder:rgba(accent,0.22),inputBorder:rgba(accent,0.16)};
    }
    function semanticDefaults(theme) {
        var values=copy(DESIGN_DEFAULTS);
        values["interaction.focus.ring"]=theme.focus;values["interaction.focus.border"]=theme.focus;
        values["interaction.hover.border"]=theme.focus;values["interaction.hover.surface"]=theme.track;
        values["interaction.selected.surface"]=theme.track;values["interaction.selected.foreground"]=theme.hot;
        values["interaction.checked.surface"]=theme.track;values["action.primary.surface"]=theme.button;
        values["action.primary.hoverSurface"]=theme.hot;values["selection.indicator.surface"]=theme.dark;
        return values;
    }
    function write(name,value){if(rootStyle&&typeof rootStyle.setProperty==="function"){rootStyle.setProperty(name,String(value));}}
    function resolveAndApply(){
        var theme=themeDefaults(),values=semanticDefaults(theme),overrides=store?store.getOverrides():{},parameters=registry?registry.list():[],parameter,cssTarget,i,key;
        for(key in baseInputs){if(Object.prototype.hasOwnProperty.call(baseInputs,key)){values[key]=baseInputs[key];}}
        for(key in overrides){if(Object.prototype.hasOwnProperty.call(overrides,key)){values[key]=overrides[key];}}
        for(key in previewOverrides){if(Object.prototype.hasOwnProperty.call(previewOverrides,key)){values[key]=previewOverrides[key];}}
        write("--gold",theme.accent);write("--gold-hot",theme.hot);write("--gold-soft",theme.soft);write("--gold-track",theme.track);write("--gold-focus",theme.focus);write("--gold-button",theme.button);write("--separator",theme.separator);write("--panel-border",theme.panelBorder);write("--input-border",theme.inputBorder);write("--selection-bg",theme.dark);write("--bg-main",values["base.canvas"]);write("--ui-scale",values["layout.scale"]);
        for(i=0;i<parameters.length;i++){parameter=parameters[i];cssTarget=CSS_TARGETS[parameter.resolverTarget];if(cssTarget&&typeof values[parameter.id]!=="undefined"){write(cssTarget,parameter.validation&&parameter.validation.type==="colorAlpha"?serializeColorAlphaValue(values[parameter.id]):values[parameter.id]);}}
        if(typeof runtime.applyMotionSpeed==="function"){runtime.applyMotionSpeed(values["motion.speed"]);}resolved=values;return copy(resolved);
    }
    function setBaseInput(id,value){var parameter=registry&&registry.get(id),checked=registry&&registry.validate(id,value);if(!parameter||parameter.persistence!=="settings"||!checked||!checked.valid)return false;baseInputs[id]=checked.value;resolveAndApply();return true;}
    function preview(id,value){var checked=registry&&registry.validate(id,value);if(!registry||!registry.isAppearanceOverride(id)||!checked||!checked.valid)return false;previewOverrides[id]=checked.value;resolveAndApply();return true;}
    function commit(id,value){var parameter=registry&&registry.get(id),checked=registry&&registry.validate(id,value);if(!parameter||!checked||!checked.valid)return false;if(parameter.persistence==="settings"){delete previewOverrides[id];if(typeof runtime.commitBaseInput!=="function"||runtime.commitBaseInput(id,checked.value)!==true)return false;baseInputs[id]=checked.value;resolveAndApply();return true;}if(!store||!store.setOverride(id,checked.value))return false;delete previewOverrides[id];store.save();resolveAndApply();return true;}
    function reset(id){delete previewOverrides[id];if(!store||!store.removeOverride(id)){resolveAndApply();return false;}store.save();resolveAndApply();return true;}
    return Object.freeze({initialize:function(inputs){var key;if(store)store.load();inputs=inputs||{};for(key in inputs){if(Object.prototype.hasOwnProperty.call(inputs,key))setBaseInput(key,inputs[key]);}return resolveAndApply();},getResolvedValue:function(id){return Object.prototype.hasOwnProperty.call(resolved,id)?resolved[id]:null;},getOverride:function(id){return store?store.getOverride(id):null;},setBaseInput:setBaseInput,preview:preview,clearPreview:function(id){delete previewOverrides[id];resolveAndApply();},commit:commit,reset:reset,resolve:resolveAndApply,getOverrides:function(){return store?store.getOverrides():{};}});
}
module.exports={createStore,createResolver,DESIGN_DEFAULTS};
