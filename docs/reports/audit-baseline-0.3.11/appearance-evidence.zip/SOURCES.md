# Pinned remote sources

These are source references, not a claim of whole-file coverage. See COVERAGE.md.

- [docs/DESIGN_SYSTEM.md](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/docs/DESIGN_SYSTEM.md)
- [docs/design/procedural-appearance.md](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/docs/design/procedural-appearance.md)
- [client/js/appearance/appearanceStateStore.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/appearance/appearanceStateStore.js)
- [client/js/appearance/appearanceResolver.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/appearance/appearanceResolver.js)
- [client/js/appearance/appearanceParameterRegistry.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/appearance/appearanceParameterRegistry.js)
- [client/js/designTuning/designTuningStateStore.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/designTuning/designTuningStateStore.js)
- [client/js/designTuning/designTuningResolver.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/designTuning/designTuningResolver.js)
- [client/js/palette/paletteStore.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/palette/paletteStore.js)
- [client/js/palette/paletteResolver.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/palette/paletteResolver.js)
- [client/js/proceduralAppearance.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/proceduralAppearance.js)
- [client/js/proceduralHomeIcons.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/proceduralHomeIcons.js)
- [client/js/ui/coreUi.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/ui/coreUi.js)
- [client/js/main.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/main.js)
- [client/js/vela/velaSurfaceController.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/vela/velaSurfaceController.js)
- [client/js/vela/velaPresentationModel.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/vela/velaPresentationModel.js)
- [client/js/statusTone.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/statusTone.js)
- [client/css/style.css](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/css/style.css)
- [client/css/velaSurface.css](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/css/velaSurface.css)
- [client/js/i18n.js](https://github.com/Lomond-PM/Lomond-Cabinet/blob/b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a/client/js/i18n.js)
