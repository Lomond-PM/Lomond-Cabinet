# Lomond Cabinet 0.3.11 源码审计证据包

- 审计日期：2026-09-08
- 仓库：Lomond-PM/Lomond-Cabinet
- 固定提交：`b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a`
- 本地探针运行环境：Node.js `v22.16.0`
- 范围结论：**跨模块深审已经形成可用发现，但全仓逐文件审计尚未完成。** 见 `COVERAGE.md`。

## 文件

| 文件 | 内容 |
| --- | --- |
| `AUDIT.md` | 12 个问题族的定位、触发条件、证据等级、修复方向和回归建议 |
| `COVERAGE.md` | 本轮阅读范围、抽查范围及未完成范围；不是全量 PASS 清单 |
| `reproduce-core.js` | Session 事件投递/不可变性、Host JSON 解析/编码摘录探针 |
| `reproduce-stream-ui.js` | 流式终态、acknowledgement、readiness 生命周期及滚动探针 |
| `reproduce-host-seams.js` | Host 坐标/Detach 摘录探针，以及明确标注的跨层行为模型 |
| `*-results.json` | 本次实际运行的输出 |
| `all-results.json` | 17 个检查场景的汇总；不等于 17 个独立漏洞 |

## 如何阅读证据

这些脚本不是从完整仓库导入所有真实依赖后运行的集成测试。它们包含摘录的源码函数/分支，以及受控依赖夹具；部分无关帮助函数被缩窄。`reproduce-host-seams.js` 中 Verify、no-op、global-disable 三项特意标注为跨层行为模型，不能据此宣称完整 Runtime/Authority/CEP/AE 路径已经复现。

脚本中的断言用于确认**固定旧基线的缺陷表现**，因此退出码 0 表示“这些旧基线表现被复现”，不是“产品正确性 PASS”。修复后应把它们转换为对正确行为的回归断言，并在真实仓库和 AE 中补齐验证。

脚本不连接网络、不调用 AE、不修改仓库、不执行生产 Host 操作。元数据解析探针只在隔离 VM 中修改一个内存标记，不提供或操作恶意工程文件。

在 Node.js 环境执行：

```powershell
node .\reproduce-core.js
node .\reproduce-stream-ui.js
node .\reproduce-host-seams.js
```

现有 JSON 文件是本轮实际保存的结果。上述命令输出到标准输出，不会自行覆盖结果文件。

## 尚未执行

没有本轮全仓 182 个离线 suite 的重新运行，没有真实 CEP/AE 验收，没有模型资格认证，没有以实际导入工程触发安全问题。上轮远程 CI 与封存报告的 PASS 不被这些探针替代，也不被当成新增场景已经覆盖的证据。
