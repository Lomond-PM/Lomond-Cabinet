'use strict';
// Baseline-only defect probes. Extracts relevant source bodies with controlled
// fixtures. These are NOT full-module, repository, native CEP or AE acceptance.
// No network, file mutation beyond stdout, shell execution or AE access.
const assert = require('node:assert/strict');
const results = [];
const BASELINE = 'b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a';
function record(id, evidence) { results.push({id, evidence}); }

// host/tools/adComponentKit.jsx: area + getLayerVisualBoundsInComp.
function area(left, top, right, bottom) {
    return {left: left, top: top, right: right, bottom: bottom,
        width: Math.max(0, right - left), height: Math.max(0, bottom - top),
        centerX: (left + right) / 2, centerY: (top + bottom) / 2};
}
function getLayerVisualBoundsInComp(layer, time) {
    var rect = null, pts, i, p;
    var left = 9999999, top = 9999999, right = -9999999, bottom = -9999999;
    try { if (layer.sourceRectAtTime) { rect = layer.sourceRectAtTime(time, false); } }
    catch (err1) { rect = null; }
    if (rect && rect.width > 0 && rect.height > 0) {
        pts = [[rect.left, rect.top], [rect.left + rect.width, rect.top],
            [rect.left + rect.width, rect.top + rect.height], [rect.left, rect.top + rect.height]];
    } else { pts = [[0,0], [layer.width || 0,0], [layer.width || 0,layer.height || 0], [0,layer.height || 0]]; }
    for (i = 0; i < pts.length; i++) {
        try { p = layer.toComp(pts[i]); } catch (err2) { p = pts[i]; }
        left = Math.min(left, p[0]); top = Math.min(top, p[1]);
        right = Math.max(right, p[0]); bottom = Math.max(bottom, p[1]);
    }
    if (left === 9999999) { left = 0; top = 0; right = 0; bottom = 0; }
    return area(left, top, right, bottom);
}
// host/tools/textBackgroundBox.jsx: layerVisualBoundsInComp.
function layerVisualBoundsInComp(layer, t) {
    var rect = null, points = [], compPoints = [], left, right, top, bottom, i, p;
    try { if (layer.sourceRectAtTime) { rect = layer.sourceRectAtTime(t, false); } }
    catch (e1) { rect = null; }
    if (!rect || rect.width <= 0 || rect.height <= 0) {
        try { if (layer.width && layer.height) { rect = {left:0, top:0, width:layer.width, height:layer.height}; } }
        catch (e2) { rect = null; }
    }
    if (!rect || rect.width <= 0 || rect.height <= 0) { return null; }
    points[0] = [rect.left, rect.top, 0];
    points[1] = [rect.left + rect.width, rect.top, 0];
    points[2] = [rect.left + rect.width, rect.top + rect.height, 0];
    points[3] = [rect.left, rect.top + rect.height, 0];
    for (i = 0; i < points.length; i++) {
        try { compPoints[i] = layer.toComp(points[i]); } catch (e3) { return null; }
    }
    left = compPoints[0][0]; right = compPoints[0][0]; top = compPoints[0][1]; bottom = compPoints[0][1];
    for (i = 1; i < compPoints.length; i++) {
        p = compPoints[i]; left = Math.min(left, p[0]); right = Math.max(right, p[0]);
        top = Math.min(top, p[1]); bottom = Math.max(bottom, p[1]);
    }
    return {left:left, top:top, width:right-left, height:bottom-top,
        centerX:(left+right)/2, centerY:(top+bottom)/2};
}
{
    // The fixture provides a valid conversion method already used by strict Icon Grid.
    // It intentionally has no expression-style toComp method.
    const layer = {width:100, height:50, sourceRectAtTime:()=>({left:0,top:0,width:100,height:50}),
        sourcePointToComp:p=>[500 + 2*p[0], 300 + 2*p[1]]};
    const wrong = getLayerVisualBoundsInComp(layer, 0);
    const refused = layerVisualBoundsInComp(layer, 0);
    const expected = area(500,300,700,400);
    assert.deepEqual([wrong.centerX,wrong.centerY], [50,25]);
    assert.equal(refused, null);
    // Positive control: the same helpers agree once the expected method is supplied.
    const control = {...layer, toComp:layer.sourcePointToComp};
    assert.deepEqual(getLayerVisualBoundsInComp(control,0), expected);
    assert.equal(layerVisualBoundsInComp(control,0).centerX, expected.centerX);
    record('HOST-COORDINATE-FALLBACK', {expectedCenter:[600,350], observedCenter:[wrong.centerX,wrong.centerY],
        genericBackgroundResult:refused, positiveControl:'passes with toComp supplied',
        limitation:'JavaScript geometry fixture; no native AE API availability assertion'});
}
{
    // host/tools/adComponentKit.jsx: exact mutation loop in detachSelectedComponent.
    // Lookup/metadata parsing are fixtures; no AE object is created.
    const priorComment = 'User-owned production note';
    const original = {parent:{name:'controller'}, comment:'LOMOND_CABINET_ARTIFACT_V1:...'};
    const layers = [{layer:original, data:{role:'sourceLayerBinding', previousCommentEncoded:encodeURIComponent(priorComment)}}];
    for (var i = 0; i < layers.length; i++) {
        layers[i].layer.parent = null;
        layers[i].layer.comment = '';
    }
    assert.equal(original.comment, '');
    assert.notEqual(original.comment, decodeURIComponent(layers[0].data.previousCommentEncoded));
    record('HOST-DETACH-SOURCE-COMMENT', {savedOriginal:priorComment, actualAfterDetach:original.comment,
        limitation:'Mutation loop with metadata fixture; native Undo and expressions not exercised'});
}

async function main() {
    {
        // Runtime verifyAction's current-selection comparison, with the Bridge's
        // capture semantics represented by a narrow observation fixture.
        const world = {A:20, B:63}; // A was committed to 63, then externally changed.
        let selected = 'B';
        const opacityVerificationPort = {observe:async()=>({fresh:true, opacity:world[selected], observationId:'new-observation'})};
        async function verifyAction(input) {
            if (input.capabilityId !== 'set-opacity-v1') {
                return Object.freeze({fresh:false, matches:false, observationRevision:null});
            }
            return opacityVerificationPort.observe().then(function(observation) {
                return Object.freeze({fresh:observation.fresh===true,
                    matches:observation.opacity===input.expectedValue.data,
                    observationRevision:observation.observationId});
            });
        }
        const input = {capabilityId:'set-opacity-v1', expectedValue:{kind:'number',data:63}};
        const result = await verifyAction(input);
        assert.equal(result.fresh, true); assert.equal(result.matches, true);
        assert.notEqual(world.A, input.expectedValue.data);
        selected = 'A';
        const control = await verifyAction(input); assert.equal(control.matches, false);
        record('VERIFY-UNBOUND-CURRENT-SELECTION', {committedTarget:'A', currentSelection:'B',
            actualCommittedTargetValue:world.A, expectedValue:63, selectedValue:world.B, verdict:result,
            positiveControl:'Selecting A correctly detects its mismatch',
            limitation:'Cross-seam behavioral model; Host execution/Authority/real race not replayed'});
    }
    {
        // Consecutive source branches, not a complete Runtime/Driver execution.
        const execution = {state:'satisfied', committed:false};
        const continuation = {committed:null, phase:'executing', verificationPlanId:'local-verify-plan'};
        continuation.committed = execution && execution.committed === true ? true : execution && execution.committed === false ? false : null;
        let result;
        if (continuation.committed === true || execution && execution.state === 'satisfied') {
            continuation.phase = 'awaiting-verification';
            result = Object.freeze({state:'verification-required',code:null});
        }
        const active = {taskId:'task',intent:{capabilityId:'set-opacity-v1'}, committed:false};
        const events = [];
        function event(kind,payload) { events.push({kind,payload}); }
        if (result && result.state === 'verification-required') {
            active.committed = true;
            event('tool/result',{taskId:active.taskId,capabilityId:active.intent.capabilityId,committed:true});
        }
        assert.equal(continuation.committed,false);
        assert.equal(events[0].payload.committed,true);
        record('NOOP-COMMIT-FACT-PROMOTION', {executionDisposition:execution,
            runtimeCommit:continuation.committed, sessionEvent:events[0],
            limitation:'Extracted handoff branches; complete review/no-op pipeline not run'});
    }
    {
        // main's settings dispatch and Surface's disabled action projection.
        // Composition's busy owner is deliberately distinct from the selected view.
        const calls = [];
        const c1 = {driver:'awaiting-review', provider:{getState:()=>({state:'pending'}),cancel:()=>calls.push('C1')}};
        const c2 = {provider:{getState:()=>({state:'completed'}),cancel:()=>calls.push('C2')}};
        let velaExperimentalSessionRequested = true;
        let experimentalEnabled = true;
        const provider = c2.provider; // selected Surface
        function disableExperimental() {
            var providerState = provider.getState();
            if (providerState && providerState.state === 'pending') { provider.cancel(); }
            experimentalEnabled = false;
            return true;
        }
        const velaSurfaceController = {disableExperimental};
        velaExperimentalSessionRequested = false;
        if (velaSurfaceController && typeof velaSurfaceController.disableExperimental === 'function') {
            velaSurfaceController.disableExperimental();
        }
        let action = 'confirm';
        // Rebinding C1 creates a disabled view because the global intent is false.
        if (!experimentalEnabled) { action = 'send'; }
        assert.deepEqual(calls,[]); assert.equal(c1.driver,'awaiting-review'); assert.equal(action,'send');
        record('GLOBAL-DISABLE-SELECTED-ONLY', {cancelCalls:calls, globalEnableIntent:velaExperimentalSessionRequested,
            hiddenOwnerState:c1.driver, actionAfterDisabledRebind:action,
            limitation:'Dispatch/projection model, not actual main/Composition/DOM integration'});
    }
    process.stdout.write(JSON.stringify({baseline:BASELINE,runtime:process.version,
        kind:'Source extracts and explicitly labelled cross-seam models; NOT full repo or CEP/AE',
        observedDefects:results},null,2)+'\n');
}
main().catch(error=>{console.error(error);process.exitCode=1;});
