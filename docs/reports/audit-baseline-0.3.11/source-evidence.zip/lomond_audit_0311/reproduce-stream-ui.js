'use strict';
// Extracted-source probes, pinned to b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a.
// This is not a full Adapter/Runtime/CEP/AE integration test.
const assert = require('node:assert/strict');
const results=[];
function record(id, evidence){results.push({id,evidence});}
// Extract: velaProviderStreamAssembler.js, factory helpers + create().
function invalid(message){var error=new Error(message);error.code='PROVIDER_RESPONSE_INVALID';throw error;}
function own(value,key){return Object.prototype.hasOwnProperty.call(value,key);}
function createAssembler(options){
    options=options||{};
    var onDelta=typeof options.onDelta==='function'?options.onDelta:function(){};
    var text='',reasoning='',structured='',buffer='';
    var done=false,frameCount=0,finishReasonObserved=null,lastValidFrameType=null;
    function consumeFrame(frame){
        if(done){if(frame.trim()){invalid('Streaming data followed [DONE].');}return;}
        var lines=frame.split(/\r?\n/);var data=[];
        lines.forEach(function(line){
            if(!line||line.charAt(0)===':'){return;}
            if(line.indexOf('data:')===0){data.push(line.slice(5).replace(/^ /,''));return;}
            if(line.indexOf('event:')===0||line.indexOf('id:')===0||line.indexOf('retry:')===0){return;}
            invalid('Malformed SSE line.');
        });
        if(!data.length){return;}
        var payload=data.join('\n');
        if(payload==='[DONE]'){done=true;lastValidFrameType='done';return;}
        var value;
        try{value=JSON.parse(payload);}catch(error){invalid('Malformed SSE JSON frame.');}
        if(!value||typeof value!=='object'||!Array.isArray(value.choices)||value.choices.length!==1||!value.choices[0]||typeof value.choices[0]!=='object'){invalid('Invalid streaming choice shape.');}
        frameCount+=1;
        if(typeof value.choices[0].finish_reason==='string'&&value.choices[0].finish_reason){finishReasonObserved=value.choices[0].finish_reason;}
        var delta=value.choices[0].delta;
        if(!delta||typeof delta!=='object'){invalid('Invalid streaming delta shape.');}
        if(own(delta,'content')){if(typeof delta.content!=='string'){invalid('Invalid streaming content delta.');}text+=delta.content;if(delta.content){onDelta('text',delta.content);}}
        ['reasoning_content','reasoning','thinking'].forEach(function(key){if(own(delta,key)){if(typeof delta[key]!=='string'){invalid('Invalid streaming reasoning delta.');}reasoning+=delta[key];if(delta[key]){onDelta('reasoning',delta[key]);}}});
        if(own(delta,'structured_content')){if(typeof delta.structured_content!=='string'){invalid('Invalid structured delta.');}structured+=delta.structured_content;}
        lastValidFrameType='delta';
    }
    function feed(chunk){var boundary;if(typeof chunk!=='string'){invalid('Streaming chunk must be text.');}if(done){if(chunk.trim()){invalid('Streaming data followed [DONE].');}return;}buffer+=chunk;while((boundary=buffer.search(/\r?\n\r?\n/))!==-1){var separator=buffer.match(/\r?\n\r?\n/)[0];consumeFrame(buffer.slice(0,boundary));buffer=buffer.slice(boundary+separator.length);}}
    function finish(){if(buffer.trim()){invalid('Streaming response ended with a partial SSE frame.');}if(!done){invalid('Streaming response ended before [DONE].');}return Object.freeze({text:text,reasoning:reasoning,structured:structured});}
    return Object.freeze({feed:feed,finish:finish,getState:function(){return Object.freeze({text:text,reasoning:reasoning,structured:structured,done:done,frameCount:frameCount,finishReasonObserved:finishReasonObserved,lastValidFrameType:lastValidFrameType,trailingBufferLength:buffer.length});}});
}
function frame(delta, finish_reason){return 'data: '+JSON.stringify({choices:[{delta,finish_reason}]})+'\n\n';}
{
    const a=createAssembler();
    a.feed(frame({content:'valid text'},'length')+frame({},'stop')+'data: [DONE]\n\n');
    const output=a.finish();
    assert.equal(a.getState().finishReasonObserved,'stop');
    record('STREAM-TERMINAL-OVERWRITE',{inputFinishReasons:['length','stop'],resultFinishReason:a.getState().finishReasonObserved,text:output.text});
    const control=createAssembler();control.feed(frame({content:'valid text'},'length')+'data: [DONE]\n\n');control.finish();
    assert.equal(control.getState().finishReasonObserved,'length');
}
{
    const a=createAssembler();a.feed(frame({content:'before'},'stop')+frame({content:'after'},null)+'data: [DONE]\n\n');
    assert.equal(a.finish().text,'beforeafter');
    record('STREAM-POST-FINISH-DELTA',{text:a.finish().text,finishReason:a.getState().finishReasonObserved});
}
// Extract: velaSurfaceController.js configureExperimental(), enableExperimental(),
// disableExperimental(), suspend()/resume() state transitions. DOM/subscriptions
// are no-op fixtures, while readiness resolution is a manually controlled promise.
function createExperimentalHarness(provider){
    var disposed=false,suspended=false,mounted=true,generation=0;
    var experimentalEnabled=false,experimentalState='disabled';
    var experimentalDisabledReason='qualification-required',readiness=null;
    var experimentalConfig={endpoint:'',model:'',acknowledged:false};
    var activationPolicy={experimentalOptInAllowed:true,productionEnabled:false},sourcePort=null;
    function synchronize(){} function notifyExperimental(){}
    function experimentalSnapshot(){return Object.freeze({state:experimentalState,enabled:experimentalEnabled,acknowledged:experimentalConfig.acknowledged===true,endpoint:experimentalConfig.endpoint,model:experimentalConfig.model,readiness:readiness});}
    function supersededSnapshot(){var snapshot=experimentalSnapshot();return Object.freeze({state:snapshot.state,enabled:snapshot.enabled,acknowledged:snapshot.acknowledged,endpoint:snapshot.endpoint,model:snapshot.model,readiness:snapshot.readiness,code:'readiness-superseded'});}
    function normalizeEndpoint(value){var match=/^http:\/\/(127\.0\.0\.1|localhost|\[::1\]):([1-9][0-9]{0,4})(?:\/|\/v1\/chat\/completions)?$/.exec(value);return match&&Number(match[2])<=65535?'http://'+match[1]+':'+match[2]:'';}
    function configureExperimental(input){
        var endpoint=input&&typeof input.endpoint==='string'?input.endpoint.replace(/^\s+|\s+$/g,''):'';
        var model=input&&typeof input.model==='string'?input.model.replace(/^\s+|\s+$/g,''):'';
        var canonicalEndpoint=normalizeEndpoint(endpoint);
        var changed=(canonicalEndpoint||endpoint)!==experimentalConfig.endpoint||model!==experimentalConfig.model;
        var providerState;
        if(changed&&(experimentalEnabled||experimentalState==='checking')){generation+=1;providerState=provider.getState();if(providerState&&providerState.state==='pending'){provider.cancel();}experimentalEnabled=false;readiness=null;}
        experimentalConfig={endpoint:canonicalEndpoint||endpoint,model:model,acknowledged:!!(input&&input.acknowledged===true)};
        experimentalDisabledReason='qualification-required';
        if(!experimentalEnabled&&(experimentalState!=='checking'||changed)){experimentalState=endpoint&&!canonicalEndpoint?'endpoint-invalid':canonicalEndpoint&&model?'configuring':'disabled';readiness=null;}
        if(mounted){synchronize();}notifyExperimental();return experimentalSnapshot();
    }
    function enableExperimental(){
        var capturedGeneration;
        if(disposed||suspended||!mounted||activationPolicy.experimentalOptInAllowed!==true||activationPolicy.productionEnabled===true||experimentalEnabled||experimentalState==='checking'){return Promise.resolve(experimentalSnapshot());}
        if(!normalizeEndpoint(experimentalConfig.endpoint)){experimentalState='endpoint-invalid';synchronize();notifyExperimental();return Promise.resolve(experimentalSnapshot());}
        if(!experimentalConfig.acknowledged||!experimentalConfig.model||typeof provider.check!=='function'){experimentalState='experimental-unavailable';synchronize();notifyExperimental();return Promise.resolve(experimentalSnapshot());}
        generation+=1;capturedGeneration=generation;experimentalState='checking';readiness=null;synchronize();notifyExperimental();
        return Promise.resolve(provider.check({endpoint:experimentalConfig.endpoint,model:experimentalConfig.model})).then(function(result){
            if(disposed||(sourcePort&&!sourcePort.isLive())||capturedGeneration!==generation||experimentalState!=='checking'){return supersededSnapshot();}
            if(!result||result.ready!==true||result.modelId!==experimentalConfig.model){experimentalState=result&&result.code||'readiness-response-invalid';readiness=result||null;}
            else{experimentalState='experimental-ready';experimentalEnabled=true;readiness=result;}
            synchronize();notifyExperimental();return experimentalSnapshot();
        },function(error){
            if(!disposed&&(!sourcePort||sourcePort.isLive())&&capturedGeneration===generation&&experimentalState==='checking'){experimentalState=error&&error.localReadinessCode||'readiness-network-failed';experimentalEnabled=false;readiness=null;synchronize();notifyExperimental();}
            return capturedGeneration!==generation?supersededSnapshot():experimentalSnapshot();
        });
    }
    function disableExperimental(){var providerState;if(disposed||!mounted){return false;}generation+=1;providerState=provider.getState();if(providerState&&providerState.state==='pending'){provider.cancel();}experimentalEnabled=false;experimentalState='disabled';experimentalDisabledReason='user-disabled';experimentalConfig={endpoint:experimentalConfig.endpoint,model:experimentalConfig.model,acknowledged:experimentalConfig.acknowledged};readiness=null;synchronize();notifyExperimental();return true;}
    function unsubscribeAgentProjection(){} function unsubscribePresentationEvents(){} function unsubscribeSource(){}
    function subscribeAgentProjection(){} function subscribePresentationEvents(){} function subscribeSource(){}
    function suspend(){if(disposed||!mounted||suspended){return false;}suspended=true;generation+=1;unsubscribeAgentProjection();unsubscribePresentationEvents();unsubscribeSource();return true;}
    function resume(){if(disposed||!mounted||!suspended){return false;}suspended=false;subscribeAgentProjection();subscribePresentationEvents();subscribeSource();if(sourcePort){sourcePort.synchronize();}synchronize();return true;}
    return {configureExperimental,enableExperimental,disableExperimental,suspend,resume,getExperimentalState:experimentalSnapshot};
}
function deferred(){let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};}
(async()=>{
    const config={endpoint:'http://127.0.0.1:1234',model:'audit-model',acknowledged:true};
    {
        const h=createExperimentalHarness({getState:()=>({state:'idle'}),cancel:()=>{},check:()=>Promise.resolve({ready:true,modelId:config.model})});
        h.configureExperimental(config);await h.enableExperimental();
        h.configureExperimental({...config,acknowledged:false});
        const s=h.getExperimentalState();assert.equal(s.enabled,true);assert.equal(s.acknowledged,false);
        record('UI-ACK-WITHDRAWAL-READY',{enabled:s.enabled,acknowledged:s.acknowledged,state:s.state});
    }
    {
        const d=deferred();const h=createExperimentalHarness({getState:()=>({state:'idle'}),cancel:()=>{},check:()=>d.promise});
        h.configureExperimental(config);const p=h.enableExperimental();h.configureExperimental({...config,acknowledged:false});d.resolve({ready:true,modelId:config.model});await p;
        const s=h.getExperimentalState();assert.equal(s.enabled,true);assert.equal(s.acknowledged,false);
        record('UI-ACK-WITHDRAWAL-CHECKING',{enabled:s.enabled,acknowledged:s.acknowledged,state:s.state});
    }
    {
        const d=deferred();let checks=0;const h=createExperimentalHarness({getState:()=>({state:'idle'}),cancel:()=>{},check:()=>{checks++;return d.promise;}});
        h.configureExperimental(config);const p=h.enableExperimental();h.suspend();d.resolve({ready:true,modelId:config.model});const old=await p;h.resume();const after=await h.enableExperimental();
        assert.equal(old.code,'readiness-superseded');assert.equal(after.state,'checking');assert.equal(after.enabled,false);assert.equal(checks,1);
        record('UI-READINESS-SUSPEND',{oldResult:old.code,stateAfterResume:after.state,enabled:after.enabled,checkCalls:checks});
    }
    // Extract: velaTranscriptView.js restoreScroll; caller passes compensateHeight=!follow.
    {
        const rootElement={scrollHeight:1200,scrollTop:100};
        function restoreScroll(follow,previousTop,previousHeight,compensateHeight){var nextHeight=Number(rootElement.scrollHeight)||0;if(follow){rootElement.scrollTop=nextHeight;}else if(compensateHeight){rootElement.scrollTop=Math.max(0,previousTop+nextHeight-previousHeight);}else{rootElement.scrollTop=previousTop;}}
        restoreScroll(false,100,1000,true);
        assert.equal(rootElement.scrollTop,300);
        record('UI-SCROLL-NONFOLLOW',{assumption:'200px appended below the visible historical message',follow:false,oldScrollTop:100,newScrollTop:rootElement.scrollTop});
    }
    console.log(JSON.stringify({baseline:'b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a',runtime:process.version,kind:'extracted-source probes with controlled fixtures; NOT real CEP/AE',observedDefects:results},null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
