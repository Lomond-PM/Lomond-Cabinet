'use strict';
// Read-only audit probes for Lomond-PM/Lomond-Cabinet @ b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a.
// This is NOT the repository test suite. It embeds the relevant source functions,
// with isolated fixtures for dependencies. It does not launch AE, perform network
// requests, edit project files, or perform Host mutations.
const assert = require('node:assert/strict');
const vm = require('node:vm');
const results = [];
function record(id, description, evidence) { results.push({id, description, evidence}); }

// Extract: client/js/vela/velaSessionRuntime.js, createSessionLog and its helpers.
// Unused authority registries remain present to preserve the function's behavior.
let defaultSessionSequence = 0;
const trustedSessionLogs = new WeakSet();
const authorityAppendBySession = new WeakMap();
const authorityPublishBySession = new WeakMap();
const trustedAuthorityEvents = new WeakSet();
const authorityEventSessions = new WeakMap();
const publishedAuthorityEvents = new WeakSet();
const ERROR_CODES = Object.freeze({SESSION_EVENT_INVALID:'SESSION_EVENT_INVALID', SESSION_CLOSED:'SESSION_CLOSED', SESSION_SEQ_GAP:'SESSION_SEQ_GAP', SESSION_AUTHORITY_EVENT_UNPUBLISHABLE:'SESSION_AUTHORITY_EVENT_UNPUBLISHABLE', SESSION_AUTHORITY_EVENT_ALREADY_PUBLISHED:'SESSION_AUTHORITY_EVENT_ALREADY_PUBLISHED'});
function fail(code) { var error = new Error(code); error.code=code; throw error; }
function isPlainObject(value) { if (!value || Object.prototype.toString.call(value)!=='[object Object]') return false; var prototype=Object.getPrototypeOf(value); return prototype===null || prototype===Object.prototype; }
function classifyEventKind(kind) { return ['user/message','agent/action-performed','tool/result','ae/state-observed'].includes(kind) ? 'fact' : ['permission/decided','delegation/granted','delegation/revoked','task/execution-armed'].includes(kind) ? 'control' : null; }
function isAuthorityEvidenceKind(kind) { return ['permission/decided','delegation/granted','delegation/revoked','task/execution-armed'].includes(kind); }
function deepFreeze(value, seen) {
    var values = seen || [];
    var keys;
    var index;
    if (!value || typeof value !== 'object' || values.indexOf(value) !== -1) { return value; }
    values.push(value);
    if (Array.isArray(value)) {
        for (index = 0; index < value.length; index += 1) { deepFreeze(value[index], values); }
    } else {
        keys = Object.keys(value);
        for (index = 0; index < keys.length; index += 1) { deepFreeze(value[keys[index]], values); }
    }
    return Object.freeze(value);
}
function createSessionLog(options) {
    var settings = isPlainObject(options) ? options : {};
    defaultSessionSequence += 1;
    var sessionId = typeof settings.sessionId === 'string' && settings.sessionId.length > 0
        ? settings.sessionId
        : 'session_' + (typeof settings.idFactory === 'function' ? settings.idFactory('session') : String(defaultSessionSequence));
    var events = [];
    var lastSeq = 0;
    var closed = false;
    var subscribers = [];
    var onListenerError = typeof settings.onListenerError === 'function' ? settings.onListenerError : function () {};
    function assertOpen() { if (closed) { fail(ERROR_CODES.SESSION_CLOSED); } }
    function normalizeEvent(input) {
        var event;
        var family;
        if (!isPlainObject(input)) { fail(ERROR_CODES.SESSION_EVENT_INVALID); }
        family = classifyEventKind(input.kind);
        if (!family) { fail(ERROR_CODES.SESSION_EVENT_INVALID); }
        event = {kind:input.kind, family:family, seq:lastSeq+1,
            requestId:typeof input.requestId==='string'?input.requestId:null,
            payload:Object.prototype.hasOwnProperty.call(input,'payload')&&isPlainObject(input.payload)?input.payload:{}};
        return event;
    }
    function appendInternal(input, authorityOwned) {
        var event;
        var index;
        assertOpen();
        event = normalizeEvent(input);
        if (authorityOwned && !isAuthorityEvidenceKind(event.kind)) { fail(ERROR_CODES.SESSION_EVENT_INVALID); }
        if (event.seq !== lastSeq + 1) { fail(ERROR_CODES.SESSION_SEQ_GAP); }
        lastSeq = event.seq;
        events.push(deepFreeze(event));
        if (authorityOwned) {
            trustedAuthorityEvents.add(events[events.length - 1]);
            authorityEventSessions.set(events[events.length - 1], sessionLog);
        }
        if (!authorityOwned) {
            for (index = 0; index < subscribers.length; index += 1) { subscribers[index](events[events.length - 1]); }
        }
        return events[events.length - 1];
    }
    function publishAuthorityInternal(event) {
        var index;
        assertOpen();
        if (!trustedAuthorityEvents.has(event) || authorityEventSessions.get(event) !== sessionLog || sessionLog.getEventBySeq(event.seq) !== event) { fail(ERROR_CODES.SESSION_AUTHORITY_EVENT_UNPUBLISHABLE); }
        if (publishedAuthorityEvents.has(event)) { fail(ERROR_CODES.SESSION_AUTHORITY_EVENT_ALREADY_PUBLISHED); }
        publishedAuthorityEvents.add(event);
        for (index = 0; index < subscribers.length; index += 1) {
            try { subscribers[index](event); }
            catch (error) { try { onListenerError(error, Object.freeze({phase:'authority-post-commit',event:event})); } catch (ignored) {} }
        }
        return true;
    }
    var sessionLog = Object.freeze({
        append:function(input){return appendInternal(input,false);},
        getEvents:function(){return deepFreeze(events.slice());},
        getEventBySeq:function(seq){if(typeof seq!=='number'||!Number.isInteger(seq)||seq<1){fail(ERROR_CODES.SESSION_EVENT_INVALID);}return seq<=events.length&&events[seq-1].seq===seq?events[seq-1]:null;},
        getSnapshot:function(){assertOpen();return deepFreeze({sessionId:sessionId,events:events.slice(),lastSeq:lastSeq});},
        project:function(fold,seed){var accumulator=seed;var index;if(typeof fold!=='function'){fail(ERROR_CODES.SESSION_EVENT_INVALID);}for(index=0;index<events.length;index+=1){accumulator=fold(accumulator,events[index]);}return accumulator;},
        subscribe:function(listener){if(typeof listener!=='function'){fail(ERROR_CODES.SESSION_EVENT_INVALID);}subscribers.push(listener);return Object.freeze({unsubscribe:function(){var index=subscribers.indexOf(listener);if(index!==-1){subscribers.splice(index,1);}}});},
        close:function(){closed=true;subscribers=[];},
        getSessionId:function(){return sessionId;},isClosed:function(){return closed;}
    });
    trustedSessionLogs.add(sessionLog);
    authorityAppendBySession.set(sessionLog,function(input){return appendInternal(input,true);});
    authorityPublishBySession.set(sessionLog,publishAuthorityInternal);
    return sessionLog;
}
{
    const log=createSessionLog(); const received=[];
    log.subscribe(e=>{if(e.payload.label==='outer') log.append({kind:'tool/result',payload:{label:'inner'}});});
    log.subscribe(e=>received.push(e.payload.label));
    const receipt=log.append({kind:'tool/result',payload:{label:'outer'}});
    assert.deepEqual(log.getEvents().map(e=>e.payload.label),['outer','inner']);
    assert.deepEqual(received,['inner','inner']);
    assert.equal(receipt.payload.label,'inner');
    record('SESSION-REENTRANCY','Nested append changes outer receipt and later subscriber delivery',{stored:['outer','inner'],delivered:received,outerReceipt:receipt.payload.label});
}
{
    let diagnosticCalls=0; const log=createSessionLog({onListenerError:()=>diagnosticCalls++}); let secondCalled=false;
    log.subscribe(()=>{throw new Error('observer failure');});
    log.subscribe(()=>{secondCalled=true;});
    assert.throws(()=>log.append({kind:'tool/result',payload:{ok:true}}),/observer failure/);
    assert.equal(log.getEvents().length,1); assert.equal(secondCalled,false); assert.equal(diagnosticCalls,0);
    record('SESSION-OBSERVER-ERROR','Ordinary subscriber exception escapes after event commit',{storedEvents:1,secondCalled,diagnosticCalls});
}
{
    const log=createSessionLog(); let n=1;
    const event=log.append({kind:'tool/result',payload:{get value(){return n;}}});
    const before=event.payload.value; n=2;
    assert(Object.isFrozen(event.payload)); assert.equal(event.payload.value,2);
    record('SESSION-ACCESSOR','Frozen historical payload still changes through getter',{frozen:true,before,after:event.payload.value});
}
{
    const log=createSessionLog(); let secondCalled=false; let first;
    first=log.subscribe(()=>first.unsubscribe());
    log.subscribe(()=>{secondCalled=true;});
    log.append({kind:'tool/result',payload:{}});
    assert.equal(secondCalled,false);
    record('SESSION-UNSUBSCRIBE','Self-unsubscribe skips the next ordinary subscriber',{secondCalled});
}

// Extract: host/index.jsx parseJson; host/tools/adComponentKit.jsx parseArtifactMetadata.
// The marker below only changes an in-memory variable; it does not touch AE or disk.
{
    const script = `
        var AEToolbox={};
        AEToolbox.parseJson=function(json){
            if(typeof JSON!=="undefined"&&JSON.parse){return JSON.parse(json);}
            return eval("("+json+")");
        };
        var ARTIFACT_METADATA_PREFIX="LOMOND_CABINET_ARTIFACT_V1:";
        function parseArtifactMetadata(comment){
            var raw=String(comment||"");var json;var data;
            if(raw.indexOf(ARTIFACT_METADATA_PREFIX)!==0){return null;}
            json=raw.substr(ARTIFACT_METADATA_PREFIX.length);
            try{data=AEToolbox.parseJson(json);}catch(err){return null;}
            if(!data||data.tool!=="adComponentKit"||!data.artifactId){return null;}
            data.aetoolbox=true;
            data.componentId=data.componentId||data.artifactId;
            data.componentType=data.componentType||data.kind;
            data.kind=data.kind||data.componentType;
            return data;
        }
        var marker=0;
        var parsed=parseArtifactMetadata('LOMOND_CABINET_ARTIFACT_V1:(function(){marker=1;return {tool:"adComponentKit",artifactId:"audit-only"};})()');
    `;
    const context=vm.createContext({JSON:undefined});
    vm.runInContext(script,context,{timeout:1000});
    assert.equal(context.marker,1); assert.equal(context.parsed.artifactId,'audit-only');
    const control=vm.createContext({JSON}); vm.runInContext(script,control,{timeout:1000});
    assert.equal(control.marker,0); assert.equal(control.parsed,null);
    record('HOST-METADATA-EVAL','Non-JSON layer metadata executes when native JSON.parse is absent',{withoutNativeJSON:context.marker,withNativeJSON:control.marker,scope:'isolated JS VM; actual AE environment not tested'});
}
// Extract: host/index.jsx jsonEscape.
{
    function jsonEscape(s){return String(s).replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\r/g,'\\r').replace(/\n/g,'\\n').replace(/\t/g,'\\t');}
    const encoded='{"name":"'+jsonEscape('a\u0001b')+'"}';
    assert.throws(()=>JSON.parse(encoded));
    assert.equal(JSON.parse('{"name":"'+jsonEscape('a\nb')+'"}').name,'a\nb');
    record('HOST-JSON-CONTROL','Control U+0001 remains unescaped and produces invalid JSON',{controlCode:1,roundTrip:'throws',newlineControl:'passes'});
}

console.log(JSON.stringify({baseline:'b93d0d8e30b4bc5f3dfc1bed7476ca112cb7f89a',runtime:process.version,kind:'extracted-source probes; NOT full-repository or AE tests',observedDefects:results},null,2));
